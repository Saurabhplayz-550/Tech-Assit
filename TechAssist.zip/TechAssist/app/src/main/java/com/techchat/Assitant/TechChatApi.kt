package com.techchat.Assitant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Client for TechChat AI. By default it calls the TechChat Supabase edge function `ai-proxy`
 * (verify_jwt = true, so the logged-in user's Supabase token is the credential) with
 * { "provider": "gemini", "payload": <Gemini generateContent body> }.
 * Set TECHCHAT_API_URL in local.properties to use a different endpoint.
 */
object TechChatApi {

    private fun endpoint(): String =
        BuildConfig.TECHCHAT_API_URL.ifBlank { BuildConfig.SUPABASE_URL.trimEnd('/') + "/functions/v1/ai-proxy" }

    private fun buildBody(system: String, history: List<Pair<String, String>>, imageB64: String?): String {
        val contents = JSONArray()
        history.forEachIndexed { i, (role, content) ->
            val parts = JSONArray().put(JSONObject().put("text", content))
            if (imageB64 != null && i == history.lastIndex) {
                parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", imageB64)))
            }
            contents.put(JSONObject().put("role", if (role == "assistant") "model" else "user").put("parts", parts))
        }
        val payload = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.2))
        return JSONObject().put("provider", "gemini").put("payload", payload).toString()
    }

    private fun extract(raw: String): String {
        try {
            val j = JSONObject(raw)
            val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            if (parts != null) {
                val sb = StringBuilder()
                for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
                if (sb.isNotBlank()) return sb.toString()
            }
            for (k in listOf("reply", "response", "content", "text", "output")) {
                val v = j.optString(k)
                if (v.isNotBlank()) return v
            }
            j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
                ?.optString("content")?.takeIf { it.isNotBlank() }?.let { return it }
        } catch (_: Exception) { }
        return raw
    }

    private fun call(body: String): Pair<Int, String> {
        val req = Request.Builder()
            .url(endpoint())
            .header("Authorization", "Bearer ${Store.accessToken.orEmpty()}")
            .header("apikey", BuildConfig.SUPABASE_ANON_KEY)
            .post(body.toRequestBody(Http.JSON))
            .build()
        return Http.client.newCall(req).execute().use { it.code to it.body?.string().orEmpty() }
    }

    suspend fun chat(system: String, history: List<Pair<String, String>>, imageB64: String?): String {
        if (BuildConfig.SUPABASE_URL.isBlank() && BuildConfig.TECHCHAT_API_URL.isBlank())
            throw IllegalStateException("Supabase/TechChat API is not configured (local.properties).")
        val body = buildBody(system, history, imageB64)
        var res = withContext(Dispatchers.IO) { call(body) }
        if (res.first == 401 && Auth.refresh()) res = withContext(Dispatchers.IO) { call(body) }
        if (res.first == 401) throw IllegalStateException("Session expired. Please log in again.")
        if (res.first !in 200..299) throw IllegalStateException("TechChat AI error ${res.first}")
        return extract(res.second)
    }
}
