package com.techchat.Assitant

import android.content.Context
import com.techchat.Assitant.ui.HoloState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * The brain loop shared by App mode and Overlay mode:
 *   read screen -> ask TechChat AI for next step -> act -> repeat until "finish".
 * Simple "open <app>" commands skip the AI and launch instantly.
 */
object Agent {
    data class Msg(val fromUser: Boolean, val text: String)

    private const val MAX_STEPS = 30
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val messages = MutableStateFlow<List<Msg>>(emptyList())
    val plan = MutableStateFlow<List<String>>(emptyList())
    val busy = MutableStateFlow(false)
    val confirm = MutableStateFlow<String?>(null)

    val holoState: Flow<HoloState> = combine(busy, Voice.speaking, Voice.listening) { b, s, l ->
        when {
            s -> HoloState.SPEAKING
            l -> HoloState.LISTENING
            b -> HoloState.THINKING
            else -> HoloState.IDLE
        }
    }

    private var job: Job? = null
    private var pending: CompletableDeferred<Boolean>? = null

    private val OPEN_RE = Regex("^(?:please\\s+)?(?:open|launch|start)\\s+(?:the\\s+)?(.+?)[.!]?$", RegexOption.IGNORE_CASE)
    private val COMPLEX_RE = Regex("\\b(and|then|in|on|to|for|search|find|play|send|read)\\b", RegexOption.IGNORE_CASE)

    private fun push(fromUser: Boolean, text: String) = messages.update { it + Msg(fromUser, text) }

    /** Show a message without speaking it. */
    fun info(text: String) = push(false, text)

    private fun say(text: String) { push(false, text); Voice.speak(text) }

    fun submit(ctx: Context, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val app = ctx.applicationContext
        push(true, t)
        job?.cancel()
        job = scope.launch {
            busy.value = true
            plan.value = emptyList()
            try {
                handle(app, t)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                say("Sorry, that failed: ${e.message}")
            } finally {
                busy.value = false
            }
        }
    }

    fun stop() {
        job?.cancel()
        pending?.complete(false)
        confirm.value = null
        plan.value = emptyList()
        Voice.stopSpeaking()
        busy.value = false
    }

    fun answerConfirm(yes: Boolean) { pending?.complete(yes) }

    private suspend fun handle(ctx: Context, task: String) {
        val m = OPEN_RE.matchEntire(task)
        if (m != null) {
            val name = m.groupValues[1].trim()
            if (!COMPLEX_RE.containsMatchIn(name) && name.split(" ").size <= 3) {
                val label = AppLauncher.launch(ctx, name)
                say(if (label != null) "Opening $label." else "I couldn't find an app called $name.")
                return
            }
        }
        runLoop(ctx, task)
    }

    private suspend fun runLoop(ctx: Context, task: String) {
        val history = mutableListOf<Pair<String, String>>()
        history += "user" to "TASK: $task"
        var planShown = false

        for (step in 1..MAX_STEPS) {
            val svc = AssistantAccessibilityService.instance
            if (svc == null) {
                say("Please turn on the Tech Assist accessibility service so I can see and control the screen.")
                AssistantAccessibilityService.openSettings(ctx)
                return
            }
            val screen = svc.dumpScreen()
            val shot = if (Store.vision) svc.screenshotBase64() else null
            history += "user" to "SCREEN (step $step):\n$screen"

            val sent = listOf(history.first()) + history.drop(1).takeLast(10)
            val reply = TechChatApi.chat(SYSTEM_PROMPT, sent, shot)
            history += "assistant" to reply

            val cmd = parse(reply)
            if (cmd == null) {
                history += "user" to "Your reply was not valid JSON. Reply with ONLY the JSON object."
                continue
            }

            cmd.optJSONArray("plan")?.let { arr ->
                val p = List(arr.length()) { arr.optString(it) }.filter { it.isNotBlank() }
                if (p.isNotEmpty()) {
                    plan.value = p
                    if (!planShown) {
                        planShown = true
                        push(false, "Plan:\n" + p.mapIndexed { i, s -> "${i + 1}) $s" }.joinToString("\n"))
                    }
                }
            }

            val action = cmd.optJSONObject("action")
            if (action == null) {
                history += "user" to "Missing \"action\". Reply with ONLY the JSON object."
                continue
            }
            val type = action.optString("type")
            val note = cmd.optString("say")

            when (type) {
                "finish" -> {
                    say(action.optString("say").ifBlank { note }.ifBlank { "Done." })
                    return
                }
                "confirm" -> {
                    val ok = askConfirm(action.optString("say").ifBlank { "Should I continue?" })
                    history += "user" to (if (ok) "User said YES. Continue." else "User said NO. Stop and finish.")
                }
                else -> {
                    val result = execute(ctx, svc, type, action)
                    history += "user" to "RESULT: $result"
                    if (note.isNotBlank()) push(false, note)
                }
            }
            delay(1100)
        }
        say("I stopped after $MAX_STEPS steps without finishing. Tell me if you want me to keep going.")
    }

    private suspend fun askConfirm(text: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        pending = d
        confirm.value = text
        push(false, text)
        Voice.speak(text)
        try {
            return d.await()
        } finally {
            confirm.value = null
        }
    }

    private suspend fun execute(ctx: Context, svc: AssistantAccessibilityService, type: String, a: JSONObject): String =
        when (type) {
            "open_app" -> AppLauncher.launch(ctx, a.optString("name"))?.let { "opened $it" } ?: "app not found"
            "tap" -> if (svc.tapId(a.optInt("id", -1))) "tapped" else "tap failed (bad id?)"
            "tap_xy" -> if (svc.tapXY(a.optDouble("x").toFloat(), a.optDouble("y").toFloat())) "tapped" else "tap failed"
            "set_text" -> if (svc.setText(a.optInt("id", -1), a.optString("text"))) "text set" else "set_text failed"
            "type" -> if (svc.typeText(a.optString("text"))) "typed" else "type failed (no focused field)"
            "enter" -> if (svc.enter()) "enter pressed" else "enter unsupported - tap the search suggestion or key instead"
            "swipe" -> if (svc.swipe(a.optString("direction"))) "swiped" else "swipe failed"
            "back" -> { svc.back(); "went back" }
            "home" -> { svc.home(); "went home" }
            "wait" -> { delay(a.optLong("ms", 1000).coerceIn(200, 5000)); "waited" }
            else -> "unknown action '$type'"
        }

    private fun parse(r: String): JSONObject? {
        val s = r.indexOf('{')
        val e = r.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try { JSONObject(r.substring(s, e + 1)) } catch (_: Exception) { null }
    }

    private val SYSTEM_PROMPT = """
You are TechChat AI, controlling an Android phone for the user through an accessibility service.
Each turn you receive the user's TASK, then the current SCREEN as a numbered list of elements
(and sometimes a screenshot). Reply with ONLY one JSON object, no markdown, in this shape:
{"plan":["step 1","step 2"],"thought":"short reasoning","action":{"type":"..."},"say":"optional short note"}

Include "plan" in your first reply and again only if the plan changes.
Action types:
 open_app {"name":"Gmail"}
 tap {"id":12}                       (id from the SCREEN list)
 tap_xy {"x":540,"y":1200}           (only if no element id fits)
 set_text {"id":5,"text":"techchat"} (replace text in an editable element)
 type {"text":"..."}                 (append to the focused field)
 enter                               (press Search/Enter on the focused field)
 swipe {"direction":"up"}            (up/down/left/right = finger movement; "up" scrolls content down)
 back | home | wait {"ms":1000}
 confirm {"say":"question"}          (ask the user yes/no BEFORE sending, paying, deleting, posting)
 finish {"say":"final answer for the user"}

Rules:
- Do one action per reply, then wait for the next SCREEN.
- Check that each action worked before moving on. If the wrong item opened, use back and try another.
- For finding an email or message: open it, read it, and confirm it matches the request before finishing.
  If it does not match, go back and try the next candidate. Report what you found in "finish".
- Never type or reveal passwords. Always use confirm before irreversible or sensitive actions.
- If you are stuck after several tries, finish and tell the user what blocked you.
""".trimIndent()
}
