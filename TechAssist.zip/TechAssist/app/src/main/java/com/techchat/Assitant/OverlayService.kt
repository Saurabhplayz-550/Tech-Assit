package com.techchat.Assitant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.techchat.Assitant.ui.HologramView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Overlay mode: the hologram floats above every app. Tap it to talk or type; drag to move. */
class OverlayService : Service() {

    companion object {
        private const val CH = "overlay"
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, OverlayService::class.java)) }
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private lateinit var bubble: TextView
    private lateinit var confirmRow: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var input: EditText
    private lateinit var holo: HologramView
    private var panelShown = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (root == null) addOverlay()
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Tech Assist overlay", NotificationManager.IMPORTANCE_LOW))
        val tap = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Tech Assist is active")
            .setContentText("Overlay assistant is running")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(tap)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, line: Int, r: Int) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), line); cornerRadius = dp(r).toFloat()
    }

    private fun chip(label: String, onClick: () -> Unit) = TextView(ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)).apply {
        text = label
        textSize = 16f
        setTextColor(Color.WHITE)
        setPadding(dp(10), dp(6), dp(10), dp(6))
        background = rounded(0xFF0A2A6B.toInt(), 0xFF00E5FF.toInt(), 10)
        setOnClickListener { onClick() }
    }

    private fun addOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val vc = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)

        bubble = TextView(vc).apply {
            setTextColor(Color.WHITE); textSize = 12f
            setPadding(dp(10), dp(8), dp(10), dp(8))
            maxWidth = dp(240)
            background = rounded(0xE6031233.toInt(), 0xFF00E5FF.toInt(), 12)
            visibility = View.GONE
            setOnClickListener { visibility = View.GONE }
        }
        confirmRow = LinearLayout(vc).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            addView(chip("Yes") { Agent.answerConfirm(true) })
            addView(chip("No") { Agent.answerConfirm(false) })
        }
        holo = HologramView(this)
        input = EditText(vc).apply {
            hint = "Ask Tech Assist…"
            setHintTextColor(0xFF7F9CD9.toInt()); setTextColor(Color.WHITE); textSize = 14f
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
            minWidth = dp(150)
            setOnEditorActionListener { _, _, _ -> sendInput(); true }
        }
        panel = LinearLayout(vc).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = rounded(0xE6031233.toInt(), 0xFF1E5BFF.toInt(), 16)
            visibility = View.GONE
            addView(chip("🎤") { listen() })
            addView(input)
            addView(chip("➤") { sendInput() })
            addView(chip("■") { Agent.stop() })
            addView(chip("✕") { showPanel(false) })
        }

        val r = LinearLayout(vc).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(bubble)
            addView(confirmRow)
            addView(holo, LinearLayout.LayoutParams(dp(130), dp(150)))
            addView(panel)
        }
        root = r

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(80) }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        holo.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val ax = (e.rawX - downX).toInt(); val ay = (e.rawY - downY).toInt()
                    if (abs(ax) > dp(6) || abs(ay) > dp(6)) moved = true
                    if (moved) { lp.x = startX + ax; lp.y = startY + ay; wm.updateViewLayout(r, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) showPanel(!panelShown)
            }
            true
        }

        wm.addView(r, lp)

        scope.launch { Agent.holoState.collect { holo.state = it } }
        scope.launch {
            Agent.messages.collect { list ->
                list.lastOrNull { !it.fromUser }?.let { bubble.text = it.text; bubble.visibility = View.VISIBLE }
            }
        }
        scope.launch {
            Agent.confirm.collect { q ->
                confirmRow.visibility = if (q != null) View.VISIBLE else View.GONE
                if (q != null) { bubble.text = q; bubble.visibility = View.VISIBLE }
            }
        }
    }

    private fun showPanel(show: Boolean) {
        panelShown = show
        panel.visibility = if (show) View.VISIBLE else View.GONE
        lp.flags = if (show) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (!show) input.clearFocus()
        root?.let { wm.updateViewLayout(it, lp) }
    }

    private fun sendInput() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        Agent.submit(this, t)
    }

    private fun listen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Agent.info("Open Tech Assist once and allow the microphone to use voice here.")
            bubble.visibility = View.VISIBLE
            return
        }
        Voice.listen(this, { Agent.submit(this, it) }, { Agent.info(it) })
    }

    override fun onDestroy() {
        scope.cancel()
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        super.onDestroy()
    }
}
