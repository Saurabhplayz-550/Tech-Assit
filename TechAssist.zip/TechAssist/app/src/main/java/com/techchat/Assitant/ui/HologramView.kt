package com.techchat.Assitant.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import java.util.Random
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

enum class HoloState { IDLE, LISTENING, THINKING, SPEAKING }

/** One mesh vertex. kind: 0 fill, 1 outline, 2 eye, 3 lower lip, 4 ear. */
private class Pt(val x: Float, val y: Float, val z: Float, val ph: Float, val kind: Int)

/** Low-poly wireframe head (triangulated glowing mesh), built once and shared. */
private object HeadMesh {
    val pts = ArrayList<Pt>()
    var edges = IntArray(0)

    private fun wAt(y: Float) = if (y > 0) 0.8f - 0.3f * (y / 1.25f).pow(1.4f) else 0.8f
    private fun inside(x: Float, y: Float): Boolean {
        val w = wAt(y); return x * x / (w * w) + y * y / (1.25f * 1.25f) < 1f
    }

    init {
        val rnd = Random(7)
        fun add(x: Float, y: Float, k: Int = 0) {
            val v = 1f - x * x / 0.64f - y * y / 1.5625f
            val z = if (k == 4) -0.05f else sqrt(max(0f, v)) * 0.55f
            pts.add(Pt(x, y, z, rnd.nextFloat() * 6.28f, k))
        }
        fun far(x: Float, y: Float, d: Float) = pts.none { (it.x - x) * (it.x - x) + (it.y - y) * (it.y - y) < d * d }

        for (i in 0 until 64) {                                   // outline
            val a = i / 64f * 6.2832f
            val y = -cos(a) * 1.25f
            add(sin(a) * (if (y > 0) wAt(y) else 0.8f), y, 1)
        }
        for (s in intArrayOf(-1, 1)) {                            // eyes + sockets
            for (i in 0 until 10) { val a = i / 10f * 6.2832f; add(s * 0.42f + cos(a) * 0.2f, -0.05f + sin(a) * 0.1f) }
            for (i in 0 until 6) { val a = i / 6f * 6.2832f; add(s * 0.42f + cos(a) * 0.4f, -0.08f + sin(a) * 0.2f) }
            add(s * 0.42f, -0.05f, 2)
            for ((ex, ey) in listOf(.86f to -.1f, .95f to -.02f, .98f to .1f, .93f to .24f, .86f to .32f)) add(s * ex, ey, 4)
        }
        for ((nx, ny) in listOf(0f to -.1f, -.1f to .15f, .1f to .15f, -.17f to .38f, .17f to .38f,
            0f to .4f, -.09f to .45f, .09f to .45f, 0f to .25f, 0f to .05f)) add(nx, ny)   // nose
        for (i in 0 until 9) { val u = i / 8f - .5f; add(u * .7f, .68f + abs(u) * .08f) }   // mouth
        for (i in 0 until 5) { val u = i / 4f - .5f; add(u * .5f, .78f + (.25f - abs(u) * .4f) * .1f, 3) }
        var n = 0
        while (n++ < 9000 && pts.size < 420) {                    // skin fill
            val x = (rnd.nextFloat() * 2 - 1) * .78f; val y = (rnd.nextFloat() * 2 - 1) * 1.22f
            if (inside(x, y) && far(x, y, .075f)) add(x, y)
        }
        val set = HashSet<Long>(); val list = ArrayList<Int>()
        for (i in pts.indices) {                                  // connect nearest neighbours
            val p = pts[i]
            val near = pts.indices.filter { it != i && (pts[it].x - p.x).pow(2) + (pts[it].y - p.y).pow(2) < .028f }
                .sortedBy { (pts[it].x - p.x).pow(2) + (pts[it].y - p.y).pow(2) }.take(5)
            for (j in near) { val key = min(i, j) * 10000L + max(i, j); if (set.add(key)) { list.add(i); list.add(j) } }
        }
        edges = list.toIntArray()
    }
}

/**
 * 3D hologram head: glowing low-poly mesh with glowing eyes, scan line and projector rings.
 * Software projection (no OpenGL) so it works identically in the app and in the overlay.
 */
class HologramView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    View(context, attrs) {

    @Volatile var state: HoloState = HoloState.IDLE

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val aura = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private val start = System.nanoTime()
    private var mouth = 0f
    private val n = HeadMesh.pts.size
    private val sx = FloatArray(n); private val sy = FloatArray(n)
    private val sz = FloatArray(n); private val sk = FloatArray(n)

    override fun onSizeChanged(nw: Int, nh: Int, ow: Int, oh: Int) {
        aura.shader = RadialGradient(nw / 2f, nh * .45f, max(1f, min(nw, nh) * .65f),
            intArrayOf(Color.argb(95, 30, 110, 255), Color.argb(0, 0, 40, 160)), null, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val t = (System.nanoTime() - start) / 1e9f
        val s = state
        val col = when (s) {
            HoloState.IDLE -> Color.rgb(46, 150, 255)
            HoloState.LISTENING -> Color.rgb(0, 235, 255)
            HoloState.THINKING -> Color.rgb(120, 130, 255)
            HoloState.SPEAKING -> Color.rgb(130, 250, 255)
        }
        val sc = min(width / 2.4f, height / 3.4f)
        val cx = width / 2f
        val cy = height * .44f + sin(t * 1.2f) * sc * .025f
        val yaw = sin(t * .7f) * .42f
        val pit = sin(t * .5f) * .05f
        val cyw = cos(yaw); val syw = sin(yaw)
        val scan = sin(t * 1.1f) * 1.2f
        val target = if (s == HoloState.SPEAKING) .35f + .65f * abs(sin(t * 11f)) * abs(sin(t * 3.7f + 1f)) else 0f
        mouth += (target - mouth) * .35f

        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), aura)

        // projector rings under the head
        val by = cy + sc * 1.5f
        line.strokeWidth = max(1.2f, sc * .01f)
        for (r in 0 until 3) {
            val k = (t * .35f + r / 3f) % 1f
            val rad = sc * (.45f + k * 1.0f)
            oval.set(cx - rad, by - rad * .22f, cx + rad, by + rad * .22f)
            line.color = col; line.alpha = (150 * (1 - k)).toInt(); c.drawOval(oval, line)
        }

        // project vertices
        for (i in 0 until n) {
            val p = HeadMesh.pts[i]
            val dy = if (p.kind == 3) mouth * .12f else 0f
            val x = p.x * cyw + p.z * syw
            val z = -p.x * syw + p.z * cyw
            val y = p.y + dy + pit * z
            val k = 1f / (1f - z * .25f)
            sx[i] = cx + x * sc * k; sy[i] = cy + y * sc * k; sz[i] = z; sk[i] = k
        }
        val e = HeadMesh.edges
        line.strokeWidth = max(.9f, sc * .006f)
        var i = 0
        while (i < e.size) {
            val a = e[i]; val b = e[i + 1]; i += 2
            val ya = HeadMesh.pts[a].y; val yb = HeadMesh.pts[b].y
            val h = max(0f, 1f - min(abs(ya - scan), abs(yb - scan)) * 5f)
            val al = (.26f + .18f * (sz[a] + sz[b]) + h * .7f).coerceIn(.05f, 1f)
            line.color = Color.argb((al * 255).toInt(),
                Color.red(col) + ((255 - Color.red(col)) * h).toInt(),
                Color.green(col) + ((255 - Color.green(col)) * h * .5f).toInt(), 255)
            c.drawLine(sx[a], sy[a], sx[b], sy[b], line)
        }
        val blink = if (t % 4f < .12f) .25f else 1f
        for (j in 0 until n) {
            val p = HeadMesh.pts[j]
            val h = max(0f, 1f - abs(p.y - scan) * 5f)
            val tw = .55f + .45f * sin(t * 2.4f + p.ph)
            dot.color = Color.rgb(140, 220, 255)
            dot.alpha = (min(1f, (.5f * tw + h) * (.7f + sz[j])) * 255).toInt().coerceIn(0, 255)
            c.drawCircle(sx[j], sy[j], (if (p.kind == 1) 1.9f else 1.3f) * sk[j] * (sc / 150f).coerceIn(.6f, 1.6f) + h * 1.5f, dot)
            if (p.kind == 2) {
                val er = sc * (.17f + .03f * sin(t * 3f)) * blink
                dot.color = col; dot.alpha = 45; c.drawCircle(sx[j], sy[j], er, dot)
                dot.alpha = 100; c.drawCircle(sx[j], sy[j], er * .55f, dot)
                dot.color = Color.rgb(225, 248, 255); dot.alpha = 245; c.drawCircle(sx[j], sy[j], er * .25f, dot)
            }
        }

        // scan glow band
        val gy = cy + scan * sc
        dot.color = col; dot.alpha = 30
        c.drawRect(cx - sc, gy - sc * .06f, cx + sc, gy + sc * .06f, dot)

        when (s) {
            HoloState.LISTENING -> {
                val f = (t * .9f) % 1f
                line.color = col; line.alpha = ((1 - f) * 170).toInt()
                c.drawCircle(cx, cy, sc * (1f + .6f * f), line)
            }
            HoloState.THINKING -> for (j in 0 until 3) {
                val a = t * 3f + j * 2.094f
                dot.color = col; dot.alpha = 255
                c.drawCircle(cx + sin(a) * sc * 1.2f, cy + cos(a) * sc * .25f, sc * .03f, dot)
            }
            else -> {}
        }
        postInvalidateOnAnimation()
    }
}
