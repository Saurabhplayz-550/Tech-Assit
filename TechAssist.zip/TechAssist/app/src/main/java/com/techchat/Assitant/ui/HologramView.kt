package com.techchat.Assitant.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

enum class HoloState { IDLE, LISTENING, THINKING, SPEAKING }

/**
 * Simple 3D hologram head: a wireframe ellipsoid with a face (eyes, nose, mouth),
 * a projector base and scan line. Software 3D projection, no OpenGL needed,
 * so it runs the same in the app and in the overlay on every Android version.
 */
class HologramView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    View(context, attrs) {

    @Volatile var state: HoloState = HoloState.IDLE

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val start = System.nanoTime()

    private var mouth = 0f
    private var yaw = 0f
    private var pitch = 0f
    private var cx = 0f
    private var cy = 0f
    private var sc = 1f
    private val o = FloatArray(3)
    private val w = FloatArray(3)

    private val RX = 0.8f
    private val RY = 1.0f
    private val RZ = 0.85f
    private val CAM = 3.2f

    override fun onSizeChanged(nw: Int, nh: Int, ow: Int, oh: Int) {
        val r = min(nw, nh) * 0.55f
        glowP.shader = RadialGradient(
            nw / 2f, nh / 2f, max(r, 1f),
            intArrayOf(Color.argb(90, 30, 110, 255), Color.argb(0, 0, 40, 160)),
            null, Shader.TileMode.CLAMP
        )
    }

    /** Rotate (yaw, pitch) then perspective-project a 3D point into [o] = (screenX, screenY, depth). */
    private fun proj(x: Float, y: Float, z: Float) {
        val cyw = cos(yaw); val syw = sin(yaw)
        val x1 = x * cyw + z * syw
        val z1 = -x * syw + z * cyw
        val cp = cos(pitch); val sp = sin(pitch)
        val y1 = y * cp - z1 * sp
        val z2 = y * sp + z1 * cp
        val k = CAM / (CAM - z2)
        o[0] = cx + x1 * k * sc
        o[1] = cy - y1 * k * sc
        o[2] = z2
    }

    private fun surface(x: Float, y: Float) {
        val v = 1f - (x / RX) * (x / RX) - (y / RY) * (y / RY)
        w[0] = x; w[1] = y; w[2] = RZ * sqrt(max(0f, v)) + 0.01f
    }

    /** Draws a 3D polyline of n segments; alpha fades with depth so the back looks dimmer. */
    private fun curve(c: Canvas, n: Int, p: Paint, alpha: Int, fn: (Int) -> Unit) {
        var px = 0f; var py = 0f; var pz = 0f
        for (i in 0..n) {
            fn(i)
            proj(w[0], w[1], w[2])
            if (i > 0) {
                val d = ((pz + o[2]) * 0.5f + 0.9f) / 1.8f
                p.alpha = (alpha * (0.2f + 0.8f * d)).coerceIn(0f, 255f).toInt()
                c.drawLine(px, py, o[0], o[1], p)
            }
            px = o[0]; py = o[1]; pz = o[2]
        }
    }

    private fun shape(c: Canvas, n: Int, fn: (Int) -> Unit, fill: Paint?, line: Paint?) {
        path.reset()
        for (i in 0 until n) {
            fn(i)
            proj(w[0], w[1], w[2])
            if (i == 0) path.moveTo(o[0], o[1]) else path.lineTo(o[0], o[1])
        }
        path.close()
        if (fill != null) c.drawPath(path, fill)
        if (line != null) c.drawPath(path, line)
    }

    override fun onDraw(c: Canvas) {
        val t = (System.nanoTime() - start) / 1e9f
        val s = state
        val col = when (s) {
            HoloState.IDLE -> Color.rgb(46, 139, 255)
            HoloState.LISTENING -> Color.rgb(0, 240, 255)
            HoloState.THINKING -> Color.rgb(108, 123, 255)
            HoloState.SPEAKING -> Color.rgb(127, 251, 255)
        }
        yaw = sin(t * 0.6f) * 0.45f
        pitch = sin(t * 0.45f) * 0.06f - 0.02f
        sc = min(width / 2.8f, height / 3.1f)
        cx = width / 2f
        cy = height / 2f - 0.15f * sc
        val lw = max(1.5f, sc * 0.012f)

        c.drawCircle(width / 2f, height / 2f, min(width, height) * 0.55f, glowP)

        stroke.color = col
        stroke.strokeWidth = lw
        fillP.color = col

        // Projector base: two rings, a spinning bright arc and faint light beams up to the head
        val by = -1.25f
        curve(c, 48, stroke, 130) { i -> val a = i * 6.2832f / 48; w[0] = 0.95f * cos(a); w[1] = by; w[2] = 0.95f * sin(a) }
        curve(c, 40, stroke, 90) { i -> val a = i * 6.2832f / 40; w[0] = 0.65f * cos(a); w[1] = by; w[2] = 0.65f * sin(a) }
        stroke.strokeWidth = lw * 2.2f
        val spin = t * 2f
        curve(c, 12, stroke, 255) { i -> val a = spin + i * 0.09f; w[0] = 0.95f * cos(a); w[1] = by; w[2] = 0.95f * sin(a) }
        stroke.strokeWidth = lw
        for (k in 0 until 12) {
            val a = k * 0.5236f
            curve(c, 1, stroke, 45) { i ->
                if (i == 0) { w[0] = 0.95f * cos(a); w[1] = by; w[2] = 0.95f * sin(a) }
                else { w[0] = 0f; w[1] = -0.95f; w[2] = 0f }
            }
        }

        // Head wireframe: meridians and latitude rings
        for (m in 0 until 10) {
            val phi = m * 3.1416f / 5f
            curve(c, 20, stroke, 150) { i ->
                val th = -1.5708f + i * 3.1416f / 20f
                w[0] = RX * cos(th) * sin(phi); w[1] = RY * sin(th); w[2] = RZ * cos(th) * cos(phi)
            }
        }
        for (l in -2..2) {
            val th = l * 0.5236f
            curve(c, 36, stroke, 150) { i ->
                val phi = i * 6.2832f / 36f
                w[0] = RX * cos(th) * sin(phi); w[1] = RY * sin(th); w[2] = RZ * cos(th) * cos(phi)
            }
        }

        // Scan line sweeping up and down the head
        val ys = sin(t * 1.2f) * 0.92f
        val thS = asin(ys / RY)
        stroke.strokeWidth = lw * 2.4f
        curve(c, 36, stroke, 255) { i ->
            val phi = i * 6.2832f / 36f
            w[0] = RX * cos(thS) * sin(phi); w[1] = RY * sin(thS); w[2] = RZ * cos(thS) * cos(phi)
        }
        stroke.strokeWidth = lw

        // Face: eyes (with blink), nose, mouth
        val blink = if ((t % 4f) < 0.12f) 0.15f else 1f
        for (side in intArrayOf(-1, 1)) {
            fillP.alpha = 170
            stroke.alpha = 255
            shape(c, 14, { i ->
                val a = i * 6.2832f / 14f
                surface(side * 0.34f + 0.14f * cos(a), 0.22f + 0.065f * blink * sin(a))
            }, fillP, stroke)
            surface(side * 0.34f, 0.22f)
            proj(w[0], w[1], w[2])
            fillP.alpha = 255
            c.drawCircle(o[0], o[1], lw * 2.2f, fillP)
        }
        stroke.alpha = 220
        curve(c, 2, stroke, 220) { i ->
            when (i) {
                0 -> surface(-0.06f, -0.16f)
                1 -> surface(0f, -0.14f)
                else -> surface(0.06f, -0.16f)
            }
        }
        curve(c, 1, stroke, 220) { i -> if (i == 0) surface(0f, 0.08f) else surface(0f, -0.14f) }

        val target = if (s == HoloState.SPEAKING) 0.35f + 0.65f * abs(sin(t * 11f)) * abs(sin(t * 3.7f + 1f)) else 0f
        mouth += (target - mouth) * 0.35f
        val open = mouth * 0.13f
        val mw = 0.28f
        val my = -0.45f
        fillP.alpha = 90
        stroke.alpha = 255
        shape(c, 18, { i ->
            if (i < 9) {
                val x = -mw + i * (2 * mw / 8f)
                surface(x, my + 0.03f * (1f - (x / mw) * (x / mw)))
            } else {
                val x = mw - (i - 9) * (2 * mw / 8f)
                surface(x, my - 0.02f - (open + 0.01f) * (1f - (x / mw) * (x / mw)))
            }
        }, fillP, stroke)

        // State effects
        when (s) {
            HoloState.LISTENING -> {
                val f = (t * 0.9f) % 1f
                stroke.alpha = ((1f - f) * 160).toInt()
                c.drawCircle(cx, cy, sc * (0.9f + 0.6f * f), stroke)
            }
            HoloState.THINKING -> {
                fillP.alpha = 255
                for (j in 0 until 3) {
                    val a = t * 3f + j * 2.094f
                    proj(1.15f * sin(a), 0.2f, 1.15f * cos(a))
                    c.drawCircle(o[0], o[1], lw * 2.5f, fillP)
                }
            }
            else -> {}
        }

        postInvalidateOnAnimation()
    }
}
