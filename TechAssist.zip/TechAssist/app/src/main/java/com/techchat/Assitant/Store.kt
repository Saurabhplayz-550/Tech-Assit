package com.techchat.Assitant

import android.content.Context
import android.content.SharedPreferences

/** Small key-value store for session + settings. */
object Store {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("techassist", Context.MODE_PRIVATE)
    }

    var accessToken: String?
        get() = sp.getString("at", null)
        set(v) { sp.edit().putString("at", v).apply() }

    var refreshToken: String?
        get() = sp.getString("rt", null)
        set(v) { sp.edit().putString("rt", v).apply() }

    var email: String?
        get() = sp.getString("email", null)
        set(v) { sp.edit().putString("email", v).apply() }

    /** Overlay mode wanted by the user. */
    var overlay: Boolean
        get() = sp.getBoolean("overlay", false)
        set(v) { sp.edit().putBoolean("overlay", v).apply() }

    /** Send screenshots to the AI (Android 11+). */
    var vision: Boolean
        get() = sp.getBoolean("vision", false)
        set(v) { sp.edit().putBoolean("vision", v).apply() }
}
