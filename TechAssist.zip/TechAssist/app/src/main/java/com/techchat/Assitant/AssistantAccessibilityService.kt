package com.techchat.Assitant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.util.SparseArray
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/** Lets the AI see the screen (UI tree + optional screenshot) and tap / swipe / type. */
class AssistantAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: AssistantAccessibilityService? = null

        fun openSettings(ctx: Context) {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private val nodes = SparseArray<AccessibilityNodeInfo>()

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    /** Numbered list of visible, useful elements. Password fields are never read. */
    fun dumpScreen(): String {
        val root = rootInActiveWindow ?: return "(no active window - the screen may still be loading)"
        nodes.clear()
        val sb = StringBuilder("APP: ${root.packageName}\n")
        var id = 0
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (id >= 250 || depth > 40) return
            if (n.isVisibleToUser && n.packageName?.toString() != packageName) {
                val text = if (n.isPassword) "[password hidden]" else n.text?.toString()?.take(120)
                val desc = n.contentDescription?.toString()?.take(80)
                val interesting = !text.isNullOrBlank() || !desc.isNullOrBlank() || n.isClickable || n.isEditable
                if (interesting) {
                    id++
                    nodes.put(id, n)
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    sb.append('[').append(id).append("] ")
                        .append(n.className?.toString()?.substringAfterLast('.') ?: "View")
                    if (!text.isNullOrBlank()) sb.append(" \"").append(text.replace("\n", " ")).append('"')
                    if (!desc.isNullOrBlank()) sb.append(" desc=\"").append(desc.replace("\n", " ")).append('"')
                    if (n.isClickable) sb.append(" {click}")
                    if (n.isEditable) sb.append(" {edit}")
                    if (n.isScrollable) sb.append(" {scroll}")
                    sb.append(" @").append(r.centerX()).append(',').append(r.centerY()).append('\n')
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, depth + 1) }
        }
        walk(root, 0)
        if (id == 0) sb.append("(no readable elements - try a screenshot or tap_xy)\n")
        return sb.toString()
    }

    private suspend fun gesture(path: Path, durationMs: Long): Boolean = suspendCancellableCoroutine { c ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (c.isActive) c.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (c.isActive) c.resume(false) }
        }, null)
        if (!ok && c.isActive) c.resume(false)
    }

    suspend fun tapXY(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return gesture(p, 60)
    }

    suspend fun tapId(id: Int): Boolean {
        val n = nodes[id] ?: return false
        n.refresh()
        var c: AccessibilityNodeInfo? = n
        var d = 0
        while (c != null && !c.isClickable && d < 6) { c = c.parent; d++ }
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        n.getBoundsInScreen(r)
        return tapXY(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun setText(id: Int, text: String): Boolean {
        val n = nodes[id] ?: return false
        n.refresh()
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun typeText(text: String): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val cur = if (f.isShowingHintText) "" else f.text?.toString().orEmpty()
        val b = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cur + text)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    /** Presses Enter/Search on the focused field. Android 11+ only. */
    fun enter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    /** direction = where the finger moves. "up" scrolls content down. */
    suspend fun swipe(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = Path()
        when (direction) {
            "up" -> { p.moveTo(w / 2, h * 0.75f); p.lineTo(w / 2, h * 0.30f) }
            "down" -> { p.moveTo(w / 2, h * 0.30f); p.lineTo(w / 2, h * 0.75f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return gesture(p, 350)
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)

    /** JPEG screenshot as base64 (Android 11+), or null. */
    suspend fun screenshotBase64(): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        return suspendCancellableCoroutine<String?> { cont ->
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        val sw = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        result.hardwareBuffer.close()
                        if (sw == null) { if (cont.isActive) cont.resume(null); return }
                        val scaled = Bitmap.createScaledBitmap(sw, 720, (sw.height * 720f / sw.width).toInt(), true)
                        val out = ByteArrayOutputStream()
                        scaled.compress(Bitmap.CompressFormat.JPEG, 60, out)
                        if (cont.isActive) cont.resume(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
                    } catch (e: Exception) {
                        if (cont.isActive) cont.resume(null)
                    }
                }
                override fun onFailure(errorCode: Int) { if (cont.isActive) cont.resume(null) }
            })
        }
    }
}
