package com.techchat.Assitant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object Http {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    val JSON = "application/json".toMediaType()
}

/**
 * Supabase email/password auth over the plain GoTrue REST API.
 * Use the SAME Supabase project as TechChat AI so existing users just log in.
 */
object Auth {
    val isLoggedIn: Boolean get() = Store.refreshToken != null

    private suspend fun post(path: String, body: JSONObject): Pair<Int, JSONObject> =
        withContext(Dispatchers.IO) {
            val req = Request.Builder()
                .url(BuildConfig.SUPABASE_URL.trimEnd('/') + path)
                .header("apikey", BuildConfig.SUPABASE_ANON_KEY)
                .post(body.toString().toRequestBody(Http.JSON))
                .build()
            Http.client.newCall(req).execute().use { r ->
                val txt = r.body?.string().orEmpty()
                r.code to (try { JSONObject(txt) } catch (e: Exception) { JSONObject() })
            }
        }

    private fun configured() = BuildConfig.SUPABASE_URL.isNotBlank() && BuildConfig.SUPABASE_ANON_KEY.isNotBlank()

    private fun error(code: Int, j: JSONObject): String =
        j.optString("error_description").ifBlank { j.optString("msg") }
            .ifBlank { j.optString("message") }.ifBlank { "Request failed ($code)" }

    private fun save(j: JSONObject): Boolean {
        val at = j.optString("access_token")
        val rt = j.optString("refresh_token")
        if (at.isBlank() || rt.isBlank()) return false
        Store.accessToken = at
        Store.refreshToken = rt
        Store.email = j.optJSONObject("user")?.optString("email") ?: Store.email
        return true
    }

    /** Returns null on success, otherwise an error message. */
    suspend fun signIn(email: String, password: String): String? {
        if (!configured()) return "Supabase is not configured. Add SUPABASE_URL and SUPABASE_ANON_KEY to local.properties."
        val (code, j) = post("/auth/v1/token?grant_type=password",
            JSONObject().put("email", email).put("password", password))
        return if (code == 200 && save(j)) null else error(code, j)
    }

    /** Returns null if signed in immediately, otherwise a message to show the user. */
    suspend fun signUp(email: String, password: String): String? {
        if (!configured()) return "Supabase is not configured."
        val (code, j) = post("/auth/v1/signup",
            JSONObject().put("email", email).put("password", password))
        if (code in 200..299) {
            return if (save(j)) null else "Account created. Check your email to confirm it, then log in."
        }
        return error(code, j)
    }

    suspend fun refresh(): Boolean {
        val rt = Store.refreshToken ?: return false
        return try {
            val (code, j) = post("/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", rt))
            code == 200 && save(j)
        } catch (e: Exception) { false }
    }

    fun signOut() {
        Store.accessToken = null
        Store.refreshToken = null
        Store.email = null
    }
}
