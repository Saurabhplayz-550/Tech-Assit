package com.techchat.Assitant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

/** Text-to-speech + speech recognition, shared by the app and the overlay. */
object Voice {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    val speaking = MutableStateFlow(false)
    val listening = MutableStateFlow(false)

    fun init(ctx: Context) {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { speaking.value = true }
                    override fun onDone(utteranceId: String?) { speaking.value = false }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { speaking.value = false }
                })
            }
        }
    }

    fun speak(text: String) {
        if (!ttsReady || text.isBlank()) return
        tts?.speak(text.take(900), TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    fun stopSpeaking() {
        tts?.stop()
        speaking.value = false
    }

    /** Must be called on the main thread and with RECORD_AUDIO granted. */
    fun listen(ctx: Context, onResult: (String) -> Unit, onFail: (String) -> Unit) {
        val app = ctx.applicationContext
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            onFail("Speech recognition isn't available on this device.")
            return
        }
        stopSpeaking()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening.value = true }
            override fun onResults(results: Bundle?) {
                listening.value = false
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                r.destroy()
                if (!t.isNullOrBlank()) onResult(t) else onFail("I didn't catch that.")
            }
            override fun onError(error: Int) {
                listening.value = false
                r.destroy()
                onFail("I didn't catch that.")
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        )
    }
}
