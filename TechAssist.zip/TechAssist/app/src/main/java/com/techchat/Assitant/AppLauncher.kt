package com.techchat.Assitant

import android.content.Context
import android.content.Intent

object AppLauncher {
    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9]"), "")

    /** Opens an installed app by its label. Returns the app label, or null if not found. */
    fun launch(ctx: Context, name: String): String? {
        val pm = ctx.packageManager
        val q = norm(name)
        if (q.isEmpty()) return null
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map { it to norm(it.loadLabel(pm).toString()) }
        val hit = apps.firstOrNull { it.second == q }
            ?: apps.firstOrNull { it.second.startsWith(q) }
            ?: apps.firstOrNull { it.second.contains(q) }
            ?: apps.firstOrNull { it.second.length >= 3 && q.contains(it.second) }
            ?: return null
        val intent = pm.getLaunchIntentForPackage(hit.first.activityInfo.packageName) ?: return null
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        (AssistantAccessibilityService.instance ?: ctx).startActivity(intent)
        return hit.first.loadLabel(pm).toString()
    }
}
