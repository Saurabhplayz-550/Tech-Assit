package com.techchat.Assitant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import android.net.Uri
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.ui.graphics.graphicsLayer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.techchat.Assitant.Agent
import com.techchat.Assitant.Auth
import com.techchat.Assitant.AssistantAccessibilityService
import com.techchat.Assitant.OverlayService
import com.techchat.Assitant.R
import com.techchat.Assitant.Store
import com.techchat.Assitant.Voice
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.launch

val Navy = Color(0xFF020617)
val Deep = Color(0xFF031A4D)
val Blue = Color(0xFF1E5BFF)
val Cyan = Color(0xFF00E5FF)
val PanelBg = Color(0xFF071533)
val Muted = Color(0xFF8FA8D9)

@Composable
fun TechTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Cyan, onPrimary = Navy, secondary = Blue,
        background = Navy, surface = PanelBg, onSurface = Color.White, onBackground = Color.White
    ),
    content = content
)

private val bg = Brush.linearGradient(listOf(Navy, Deep, Navy))

/** Increments each time the activity resumes, to refresh permission/service status. */
@Composable
fun resumeTick(): Int {
    val act = LocalContext.current as ComponentActivity
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(act) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        act.lifecycle.addObserver(obs)
        onDispose { act.lifecycle.removeObserver(obs) }
    }
    return tick
}

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    var loggedIn by remember { mutableStateOf(Auth.isLoggedIn) }
    var page by remember { mutableStateOf("home") }

    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (Auth.isLoggedIn) Auth.refresh()
    }

    val authTick by Auth.authTick.collectAsState()
    LaunchedEffect(authTick) { if (Auth.isLoggedIn) loggedIn = true }

    val tick = resumeTick()
    LaunchedEffect(tick) {
        if (loggedIn && Store.overlay && Settings.canDrawOverlays(ctx)) OverlayService.start(ctx)
    }

    when {
        !loggedIn -> LoginScreen { loggedIn = true }
        page == "settings" -> SettingsScreen(
            onBack = { page = "home" },
            onLogout = {
                Agent.stop(); OverlayService.stop(ctx); Auth.signOut(); loggedIn = false; page = "home"
            }
        )
        else -> HomeScreen(onSettings = { page = "settings" })
    }
}

@Composable
fun LoginScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var email by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var create by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val extErr by Auth.authError.collectAsState()
    val scope = rememberCoroutineScope()

    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, tween(1000, easing = FastOutSlowInEasing)) }
    val inf = rememberInfiniteTransition(label = "login")
    val edge by inf.animateColor(
        Blue, Cyan, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "edge"
    )

    Column(
        Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().height(290.dp).graphicsLayer { alpha = enter.value }) {
            AndroidView(factory = { HologramView(it) }, modifier = Modifier.fillMaxSize())
        }
        Text(
            "Tech Assist", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White,
            modifier = Modifier.graphicsLayer { alpha = enter.value; translationY = (1f - enter.value) * 40f }
        )
        Text(
            "Your TechChat AI phone assistant", color = Cyan, fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 18.dp).graphicsLayer { alpha = enter.value }
        )
        Column(
            Modifier.fillMaxWidth()
                .graphicsLayer { alpha = enter.value; translationY = (1f - enter.value) * 160f }
                .clip(RoundedCornerShape(26.dp))
                .background(Color(0xAA071533))
                .border(1.dp, edge.copy(alpha = 0.55f), RoundedCornerShape(26.dp))
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(if (create) "Create account" else "Welcome back", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)

            Button(
                onClick = {
                    val url = Auth.googleUrl()
                    if (url == null) msg = "Supabase is not configured. Add SUPABASE_URL and SUPABASE_ANON_KEY to local.properties."
                    else { msg = null; Auth.authError.value = null; ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF1B1F27)),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Image(painterResource(R.drawable.ic_google), "Google", Modifier.size(22.dp))
                Spacer(Modifier.width(12.dp))
                Text("Continue with Google", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).height(1.dp).background(Color(0x3350A0FF)))
                Text("  OR  ", color = Muted, fontSize = 12.sp)
                Box(Modifier.weight(1f).height(1.dp).background(Color(0x3350A0FF)))
            }

            val fc = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Cyan, unfocusedBorderColor = Color(0x5550A0FF),
                focusedLabelColor = Cyan, cursorColor = Cyan
            )
            OutlinedTextField(
                email, { email = it }, label = { Text("Email") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = fc,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                pw, { pw = it }, label = { Text("Password") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = fc,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {}),
                modifier = Modifier.fillMaxWidth()
            )
            (msg ?: extErr)?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp) }
            Button(
                onClick = {
                    busy = true; msg = null; Auth.authError.value = null
                    scope.launch {
                        val err = try {
                            if (create) Auth.signUp(email.trim(), pw) else Auth.signIn(email.trim(), pw)
                        } catch (e: Exception) { "Network error. Check your connection." }
                        busy = false
                        if (err == null && Auth.isLoggedIn) onDone() else msg = err
                    }
                },
                enabled = !busy && email.isNotBlank() && pw.length >= 6,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) { Text(if (busy) "Please wait…" else if (create) "Create account" else "Log in", fontWeight = FontWeight.SemiBold) }
            TextButton(onClick = { create = !create; msg = null }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text(if (create) "Already have TechChat AI? Log in" else "New here? Create an account", color = Cyan)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun RoundBtn(label: String, filled: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val fillBrush = if (filled && enabled) Brush.linearGradient(listOf(Blue, Cyan)) else Brush.linearGradient(listOf(PanelBg, PanelBg))
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(fillBrush)
            .border(1.dp, Color(0x4450A0FF), CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White.copy(alpha = if (enabled) 1f else 0.4f), fontSize = 18.sp) }
}

@Composable
fun HomeScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val holo by Agent.holoState.collectAsState(HoloState.IDLE)
    val msgs by Agent.messages.collectAsState()
    val busy by Agent.busy.collectAsState()
    val confirm by Agent.confirm.collectAsState()
    val tick = resumeTick()
    val a11yOn = remember(tick) { AssistantAccessibilityService.instance != null }
    var text by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.3f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "dot"
    )

    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    val listen = { Voice.listen(ctx, { Agent.submit(ctx, it) }, { Agent.info(it) }) }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) listen() else Agent.info("Microphone permission is needed for voice.")
    }
    fun send() { val t = text.trim(); if (t.isNotEmpty()) { text = ""; Agent.submit(ctx, t) } }

    Column(Modifier.fillMaxSize().background(bg).padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.logo), null, Modifier.size(32.dp).clip(RoundedCornerShape(9.dp)))
            Text("  Tech Assist", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onSettings) { Text("Settings", color = Cyan) }
        }
        if (!a11yOn) {
            Text(
                "Screen control is off. Tap here to enable the Tech Assist accessibility service.",
                color = Color(0xFFFFD180), fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { AssistantAccessibilityService.openSettings(ctx) }
            )
        }
        Box(Modifier.fillMaxWidth().weight(0.95f)) {
            AndroidView(factory = { HologramView(it) }, modifier = Modifier.fillMaxSize(), update = { it.state = holo })
            Row(
                Modifier.align(Alignment.BottomCenter).clip(RoundedCornerShape(50)).background(Color(0x66071533))
                    .padding(horizontal = 14.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Cyan.copy(alpha = if (holo == HoloState.IDLE) 0.5f else pulse)))
                Text(
                    "  " + when (holo) {
                        HoloState.IDLE -> "Ready"
                        HoloState.LISTENING -> "Listening…"
                        HoloState.THINKING -> "Working on it…"
                        HoloState.SPEAKING -> "Speaking…"
                    }, color = Cyan, fontSize = 13.sp
                )
            }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(top = 6.dp)
                .clip(RoundedCornerShape(20.dp)).background(Color(0x33071533)).padding(10.dp),
            state = list, verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (msgs.isEmpty()) item {
                Text("Try: \"open YouTube\" or \"find the mail with my TechChat verification code in Gmail\".", color = Muted, fontSize = 13.sp)
            }
            items(msgs) { m ->
                Box(Modifier.fillMaxWidth().animateItem(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(
                        m.text, color = Color.White, fontSize = 14.sp,
                        modifier = Modifier.clip(RoundedCornerShape(16.dp))
                            .background(if (m.fromUser) Brush.linearGradient(listOf(Blue, Color(0xFF2A7BFF))) else Brush.linearGradient(listOf(PanelBg, PanelBg)))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundBtn("🎤") {
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listen()
                else mic.launch(Manifest.permission.RECORD_AUDIO)
            }
            OutlinedTextField(
                text, { text = it }, placeholder = { Text("Tell Tech Assist what to do") },
                singleLine = true, shape = RoundedCornerShape(26.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Color(0x5550A0FF), cursorColor = Cyan),
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            if (busy) RoundBtn("■") { Agent.stop() }
            else RoundBtn("➤", filled = true, enabled = text.isNotBlank()) { send() }
        }
    }

    confirm?.let { q ->
        AlertDialog(
            onDismissRequest = { Agent.answerConfirm(false) },
            title = { Text("Confirm") },
            text = { Text(q) },
            confirmButton = { TextButton(onClick = { Agent.answerConfirm(true) }) { Text("Yes") } },
            dismissButton = { TextButton(onClick = { Agent.answerConfirm(false) }) { Text("No") } }
        )
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val tick = resumeTick()
    var overlay by remember(tick) { mutableStateOf(Store.overlay && Settings.canDrawOverlays(ctx)) }
    var vision by remember { mutableStateOf(Store.vision) }
    val a11yOn = remember(tick) { AssistantAccessibilityService.instance != null }

    Column(
        Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Back", color = Cyan) }
            Text("Settings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        SettingRow("Overlay mode", "Show the hologram over every app, even when Tech Assist is closed.", overlay) { on ->
            Store.overlay = on
            if (on) {
                if (Settings.canDrawOverlays(ctx)) { overlay = true; OverlayService.start(ctx) }
                else ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            } else { overlay = false; OverlayService.stop(ctx) }
        }
        SettingRow("Screen vision", "Send screenshots to the AI as well as the screen text (Android 11+).", vision) {
            vision = it; Store.vision = it
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Screen control", color = Color.White, fontSize = 16.sp)
                Text(if (a11yOn) "On: the AI can see, tap and swipe." else "Off: enable the accessibility service.", color = Muted, fontSize = 12.sp)
            }
            OutlinedButton(onClick = { AssistantAccessibilityService.openSettings(ctx) }) { Text(if (a11yOn) "Manage" else "Enable") }
        }
        Text(
            "On Android 13+ if you installed from an APK, open App info > ⋮ > Allow restricted settings first.",
            color = Muted, fontSize = 12.sp
        )
        Text("Signed in as ${Store.email ?: "your TechChat AI account"}", color = Muted, fontSize = 13.sp)
        OutlinedButton(onClick = onLogout) { Text("Log out") }
    }
}

@Composable
private fun SettingRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp)
            Text(sub, color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
