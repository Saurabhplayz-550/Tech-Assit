package com.techchat.Assitant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.techchat.Assitant.Agent
import com.techchat.Assitant.Auth
import com.techchat.Assitant.AssistantAccessibilityService
import com.techchat.Assitant.OverlayService
import com.techchat.Assitant.R
import com.techchat.Assitant.Store
import com.techchat.Assitant.Voice
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.launch

val Navy = Color(0xFF020617)
val Deep = Color(0xFF031A4D)
val Blue = Color(0xFF1E5BFF)
val Cyan = Color(0xFF00E5FF)
val PanelBg = Color(0xFF071533)
val Muted = Color(0xFF8FA8D9)

@Composable
fun TechTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Cyan, onPrimary = Navy, secondary = Blue,
        background = Navy, surface = PanelBg, onSurface = Color.White, onBackground = Color.White
    ),
    content = content
)

private val bg = Brush.linearGradient(listOf(Navy, Deep, Navy))

/** Increments each time the activity resumes, to refresh permission/service status. */
@Composable
fun resumeTick(): Int {
    val act = LocalContext.current as ComponentActivity
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(act) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        act.lifecycle.addObserver(obs)
        onDispose { act.lifecycle.removeObserver(obs) }
    }
    return tick
}

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    var loggedIn by remember { mutableStateOf(Auth.isLoggedIn) }
    var page by remember { mutableStateOf("home") }

    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (Auth.isLoggedIn) Auth.refresh()
    }

    val tick = resumeTick()
    LaunchedEffect(tick) {
        if (loggedIn && Store.overlay && Settings.canDrawOverlays(ctx)) OverlayService.start(ctx)
    }

    when {
        !loggedIn -> LoginScreen { loggedIn = true }
        page == "settings" -> SettingsScreen(
            onBack = { page = "home" },
            onLogout = {
                Agent.stop(); OverlayService.stop(ctx); Auth.signOut(); loggedIn = false; page = "home"
            }
        )
        else -> HomeScreen(onSettings = { page = "settings" })
    }
}

@Composable
fun LoginScreen(onDone: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var create by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Row(
        Modifier.fillMaxSize().background(bg).padding(24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo), "Tech Assist logo", Modifier.size(140.dp).clip(RoundedCornerShape(28.dp)))
            Spacer(Modifier.height(12.dp))
            Text("Tech Assist", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Your TechChat AI phone assistant", color = Cyan, fontSize = 14.sp)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(if (create) "Create account" else "Log in with your TechChat AI account", color = Color.White, fontSize = 18.sp)
            OutlinedTextField(
                email, { email = it }, label = { Text("Email") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                pw, { pw = it }, label = { Text("Password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {}),
                modifier = Modifier.fillMaxWidth()
            )
            msg?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp) }
            Button(
                onClick = {
                    busy = true; msg = null
                    scope.launch {
                        val err = try {
                            if (create) Auth.signUp(email.trim(), pw) else Auth.signIn(email.trim(), pw)
                        } catch (e: Exception) { "Network error. Check your connection." }
                        busy = false
                        if (err == null && Auth.isLoggedIn) onDone() else msg = err
                    }
                },
                enabled = !busy && email.isNotBlank() && pw.length >= 6,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "Please wait…" else if (create) "Create account" else "Log in") }
            TextButton(onClick = { create = !create; msg = null }) {
                Text(if (create) "Already have TechChat AI? Log in" else "New here? Create an account", color = Cyan)
            }
        }
    }
}

@Composable
fun HomeScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val holo by Agent.holoState.collectAsState(HoloState.IDLE)
    val msgs by Agent.messages.collectAsState()
    val plan by Agent.plan.collectAsState()
    val busy by Agent.busy.collectAsState()
    val confirm by Agent.confirm.collectAsState()
    val tick = resumeTick()
    val a11yOn = remember(tick) { AssistantAccessibilityService.instance != null }
    var text by remember { mutableStateOf("") }
    val list = rememberLazyListState()

    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    val listen = { Voice.listen(ctx, { Agent.submit(ctx, it) }, { Agent.info(it) }) }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) listen() else Agent.info("Microphone permission is needed for voice.")
    }
    fun send() { val t = text.trim(); if (t.isNotEmpty()) { text = ""; Agent.submit(ctx, t) } }

    Row(Modifier.fillMaxSize().background(bg).padding(12.dp)) {
        Box(Modifier.weight(1f).fillMaxHeight()) {
            AndroidView(factory = { HologramView(it) }, modifier = Modifier.fillMaxSize(), update = { it.state = holo })
            Text(
                when (holo) {
                    HoloState.IDLE -> "Ready"
                    HoloState.LISTENING -> "Listening…"
                    HoloState.THINKING -> "Working on it…"
                    HoloState.SPEAKING -> "Speaking…"
                },
                color = Cyan, fontSize = 14.sp, modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
        Column(Modifier.weight(1.15f).fillMaxHeight().padding(start = 8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo), null, Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)))
                Text("  Tech Assist", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = onSettings) { Text("Settings", color = Cyan) }
            }
            if (!a11yOn) {
                Text(
                    "Screen control is off. Tap here to enable the Tech Assist accessibility service.",
                    color = Color(0xFFFFD180), fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .clickable { AssistantAccessibilityService.openSettings(ctx) }
                )
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (msgs.isEmpty()) item {
                    Text("Try: \"open YouTube\" or \"find the mail with my TechChat verification code in Gmail\".", color = Muted, fontSize = 13.sp)
                }
                items(msgs) { m ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                        Text(
                            m.text, color = Color.White, fontSize = 14.sp,
                            modifier = Modifier.clip(RoundedCornerShape(14.dp))
                                .background(if (m.fromUser) Blue else PanelBg)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listen()
                    else mic.launch(Manifest.permission.RECORD_AUDIO)
                }) { Text("🎤") }
                OutlinedTextField(
                    text, { text = it }, placeholder = { Text("Tell Tech Assist what to do") },
                    singleLine = true, modifier = Modifier.weight(1f).padding(horizontal = 6.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { send() })
                )
                if (busy) OutlinedButton(onClick = { Agent.stop() }) { Text("■") }
                else Button(onClick = { send() }, enabled = text.isNotBlank()) { Text("➤") }
            }
        }
    }

    confirm?.let { q ->
        AlertDialog(
            onDismissRequest = { Agent.answerConfirm(false) },
            title = { Text("Confirm") },
            text = { Text(q) },
            confirmButton = { TextButton(onClick = { Agent.answerConfirm(true) }) { Text("Yes") } },
            dismissButton = { TextButton(onClick = { Agent.answerConfirm(false) }) { Text("No") } }
        )
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val tick = resumeTick()
    var overlay by remember(tick) { mutableStateOf(Store.overlay && Settings.canDrawOverlays(ctx)) }
    var vision by remember { mutableStateOf(Store.vision) }
    val a11yOn = remember(tick) { AssistantAccessibilityService.instance != null }

    Column(
        Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Back", color = Cyan) }
            Text("Settings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        SettingRow("Overlay mode", "Show the hologram over every app, even when Tech Assist is closed.", overlay) { on ->
            Store.overlay = on
            if (on) {
                if (Settings.canDrawOverlays(ctx)) { overlay = true; OverlayService.start(ctx) }
                else ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            } else { overlay = false; OverlayService.stop(ctx) }
        }
        SettingRow("Screen vision", "Send screenshots to the AI as well as the screen text (Android 11+).", vision) {
            vision = it; Store.vision = it
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Screen control", color = Color.White, fontSize = 16.sp)
                Text(if (a11yOn) "On: the AI can see, tap and swipe." else "Off: enable the accessibility service.", color = Muted, fontSize = 12.sp)
            }
            OutlinedButton(onClick = { AssistantAccessibilityService.openSettings(ctx) }) { Text(if (a11yOn) "Manage" else "Enable") }
        }
        Text(
            "On Android 13+ if you installed from an APK, open App info > ⋮ > Allow restricted settings first.",
            color = Muted, fontSize = 12.sp
        )
        Text("Signed in as ${Store.email ?: "your TechChat AI account"}", color = Muted, fontSize = 13.sp)
        OutlinedButton(onClick = onLogout) { Text("Log out") }
    }
}

@Composable
private fun SettingRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp)
            Text(sub, color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
