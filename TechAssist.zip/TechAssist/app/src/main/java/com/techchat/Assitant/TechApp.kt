package com.techchat.Assitant

import android.app.Application

class TechApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Voice.init(this)
    }
}
