package com.techchat.Assitant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.techchat.Assitant.ui.AppRoot
import com.techchat.Assitant.ui.TechTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TechTheme { AppRoot() } }
    }
}
