package com.techchat.Assitant

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.techchat.Assitant.ui.AppRoot
import com.techchat.Assitant.ui.TechTheme
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleAuth(intent)
        setContent { TechTheme { AppRoot() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAuth(intent)
    }

    /** Google sign-in returns here through the techassist://auth-callback link. */
    private fun handleAuth(i: Intent?) {
        val d = i?.data ?: return
        if (d.scheme == "techassist") MainScope().launch { Auth.handleCallback(d) }
    }
}
