import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val props = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun p(key: String) = props.getProperty(key) ?: ""

android {
    namespace = "com.techchat.Assitant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.techchat.Assitant"
        minSdk = 29          // Android 10
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "SUPABASE_URL", "\"${p("SUPABASE_URL")}\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\"${p("SUPABASE_ANON_KEY")}\"")
        buildConfigField("String", "GEMINI_API_KEY", "\"${p("GEMINI_API_KEY")}\"")
        buildConfigField("String", "GEMINI_MODEL", "\"${p("GEMINI_MODEL").ifBlank { "gemini-2.5-flash" }}\"")
        buildConfigField("String", "TECHCHAT_API_URL", "\"${p("TECHCHAT_API_URL")}\"")
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
