# Tech Assist (com.techchat.Assitant)

Portrait Android assistant powered by TechChat AI. Min SDK 29 (Android 10), target 35.

## Setup
1. Open this folder in Android Studio (Ladybug or newer). It will create the Gradle wrapper and sync.
2. Copy `local.properties.example` to `local.properties` and fill in:
   - `SUPABASE_URL`, `SUPABASE_ANON_KEY`: the SAME Supabase project TechChat AI uses, so existing users just log in.
   - `TECHCHAT_API_URL`: optional; blank = ai-proxy edge function.
3. Optional: set `GEMINI_API_KEY` in `local.properties` to call Gemini directly (skips ai-proxy). `TechChatApi.kt` already calls the TechChat Supabase edge function `ai-proxy` (Gemini). Change TECHCHAT_API_URL to use another endpoint.
4. Run on a device. Enable "Screen control" (accessibility) in Settings, then the Overlay toggle.

## Google sign-in
The login screen has **Continue with Google** (Supabase OAuth, same as TechChat AI). One-time setup in the Supabase dashboard:
- Authentication > Providers > Google: enabled (already is for TechChat AI).
- Authentication > URL Configuration > Redirect URLs: add `techassist://auth-callback`.

## Modes
- App mode: type or speak. "open YouTube" launches instantly; longer tasks run the plan -> read screen -> act loop.
- Overlay mode: floating 3D hologram over every app (foreground service). Tap = talk/type, drag = move.

## Android version notes
- Android 10: UI text tree only (screenshots need Android 11+).
- Android 13+: sideloaded APKs need App info > Allow restricted settings before accessibility can be enabled.
- Android 14+: overlay runs as a `specialUse` foreground service (declared in the manifest).
- Play Store: apps using the Accessibility API for automation need a Play Console declaration and may be rejected; direct APK is simplest.
